from tkinter import *
import math

# stop watch timer program
# ---------------------------- CONSTANTS ------------------------------- #
PINK = "#e2979c"
RED = "#e7305b"
GREEN = "#9bdeac"
YELLOW = "#f7f5dd"
FONT_NAME = "Courier"
WORK_MIN = 25
SHORT_BREAK_MIN = 5
LONG_BREAK_MIN = 20
timer = None

# ---------------------------- TIMER START MECHANISM ------------------------------- #

# ---------------------------- UI SETUP ------------------------------- #

# creating an window tab using tk inter module
window_tab = Tk()
window_tab.title("stop watch timer")
# changing the background color of the window tab
# keyword "bg"-> this changes the background color of the window tab
# 'highlight-thickness reduces the thickness color of the borderlines of the image
window_tab.config(padx=150, pady=100, bg="light yellow")

# creating an canvas class.
# canvas() -> this method allows you to create image, add texts into the image
# changing the color of the canvas background
# 'highlight-thickness reduces the thickness color of the borderlines of the image
canvas = Canvas(width=205, height=224, bg="light yellow", highlightthickness=0)
# importing the image into the canvas image and adding the texts
# creating an variable to store the image position
# PhotoImage this is an method that allows you to store the images in tkinter module
tomato_image = PhotoImage(file="tomato.png")
# setting the height and width of the image
canvas.create_image(103, 112, image=tomato_image)
# creating  a text into the image
# canvas.create_text(100, 130, text="00:00", fill="white", font=("Courier", 35, "bold"))
# storing this canvas text into a text variable so we can use it in the count mechanism
timer_text = canvas.create_text(100, 130, text="00:00", fill="white", font=("Courier", 35, "bold"))
canvas.grid(column=1, row=1)

# creating timer label
# 'fg'-> changes the color of the texts
timer_label = Label(text="Timer", font=("courier", 50, "normal"), bg="light yellow", fg="green")
timer_label.grid(column=1, row=0)

# ---------------------------- TIMER START MECHANISM ------------------------------- #
# when the start button is clicked the timer should start the countdown
# setting the reps between each work time
reps = 0


def start_count_down():
    # 5 * 60 = 300 the countdown starts from 300 secs when the start button is clicked . 300 = 5 mins count_down(5 *
    # 60) adding break time mins between the work time and making the timer to go back to its work time after the
    # break time.
    global reps
    reps += 1
    work_sec = WORK_MIN * 60
    # setting the short break seconds
    short_break_secs = SHORT_BREAK_MIN * 60
    # long break
    long_break_secs = LONG_BREAK_MIN * 60
    if reps % 8 == 0:
        count_down(long_break_secs)
        timer_label.config(text="Long Break!", font=("courier", 50, "normal"), bg="light yellow", fg="red")
    # if the reps is 2/4/6.
    elif reps % 2 == 0:
        count_down(short_break_secs)
        timer_label.config(text="Short Break!", font=("courier", 50, "normal"), bg="light yellow", fg="pink")
    else:
        count_down(work_sec)
        timer_label.config(text="Work Time", font=("courier", 50, "normal"), bg="light yellow", fg="green")


# creating start and rest buutons
# adding a highlight-thickness keyword to reduce the thickness the button,
start_button = Button(text="Start", font=("Courier", 10, "bold"), highlightthickness=0, command=start_count_down)
start_button.grid(column=0, row=2)


# reset button
# ---------------------------- TIMER RESET ------------------------------- #
def timer_reset():
    window_tab.after_cancel(timer)
    canvas.itemconfig(timer_text, text="00:00")
    timer_label.config(text="Timer")
    # setting the reps as 0 when we hit the reset button
    global reps
    reps = 0


reset_button = Button(text="Reset", font=("Courier", 10, "bold"), highlightthickness=0, command=timer_reset)
reset_button.grid(column=2, row=2)
# adding a check mark label into the window tab
checkmark_label = Label(text="✅", font=(FONT_NAME, 20), bg="light yellow", fg="green")
checkmark_label.grid(column=1, row=4)


# stop button
def stop_timer():
    window_tab.after_cancel(timer)
    global reps
    reps = 0


stop_button = Button(text="stop", font=("Courier", 10, "bold"), highlightthickness=0, command=stop_timer)
stop_button.grid(column=1, row=4)


# ---------------------------- COUNTDOWN MECHANISM ------------------------------- #
# after()-> this method allows the window to show the texts after some time delay
# here count is the unlimited positional arguments (*args)
def count_down(count):
    # print(count)
    # math.floor()-> this method gets the largest whole number of the decimal point
    # creating an if statement
    count_min = math.floor(count / 60)
    count_sec = count % 60
    if count_sec < 10:
        count_sec = f"0{count_sec}"
    canvas.itemconfig(timer_text, text=f"{count_min}:{count_sec}")
    # adding an if statement to set particular count down
    if count > 0:
        # giving this a variable called timer
        # 1000 = 1 sec
        global timer
        timer = window_tab.after(1000, count_down, count - 1)
    # after the timer completes the work min it should go to the break session
    else:
        start_count_down()


window_tab.mainloop()
