# stop watch program using graphical user interface (GUI)
# importing every class from the tkinter module
from tkinter import *
import math

# importing PIL package to import images from google
# from PIL import ImageTk, Image

# setting the timings.
WORK_MIN = 30
SHORT_BREAK_MIN = 5
LONG_BREAK_MIN = 20
# setting the global varibale timer value as none when the reset button is clicked
timer = None
# creating the UI setup

# creating the window tab
window_tab = Tk()
window_tab.title("stop watch")
# setting the window height and width
# setting the background color of the window
window_tab.config(padx=150, pady=100, bg="light blue")

# creating the canvas and canvas image into it
canvas = Canvas(width=205, height=224, bg="light blue", highlightthickness=0)
photo_img = PhotoImage(file="tomato.png")
# setting the image size
canvas.create_image(103, 112, image=photo_img)
canvas.grid(column=1, row=1)

# creating timer text inside the canvas image
# chaning the color of the text inside the canvas image. fill()->
timer_text = canvas.create_text(100, 130, text="00:00", font=("Courier", 35, "bold"), fill="white")

# creating timer label on the top of the canvas image
timer_label = Label(text="Timer", font=("Courier", 50, "bold"), bg="light blue", fg="pink")
timer_label.grid(column=1, row=0)

# setting each sessions as reps
reps = 0


# creating start button
# ----- TIMER START MECHANISHM------------#
def start_timer():
    # converting this 300 secs into mins
    # count_down(5 * 60) -> 300mins
    # now adding worktime and break session sinto start button
    global reps
    reps += 1
    # the work time
    # 30 *60 = 1,800, 1,800/60 = 30mins
    work_sec = WORK_MIN * 60
    short_break_sec = SHORT_BREAK_MIN * 60
    long_break_sec = LONG_BREAK_MIN * 60
    # adding a conditional statments to each sessions
    if reps % 8 == 0:
        count_down(long_break_sec)
        timer_label.config(text="Long break!", font=("Courier", 50, "bold"), bg="light blue", fg="light purple")
    elif reps % 2 == 0:
        count_down(short_break_sec)
        timer_label.config(text="Short Break!", font=("Courier", 50, "bold"), bg="light blue", fg="red")
    else:
        count_down(work_sec)
        timer_label.config(text="Work Time", font=("Courier", 50, "bold"), bg="light blue", fg="dark blue")


start_button = Button(text="Start", font=("courier", 10, "bold"), highlightthickness=0, bg="light green",
                      activebackground="light green", command=start_timer)
start_button.grid(column=0, row=2)


# ---------- RESET MECHANISM-----------------#
def reset_timer():
    # window_tab.after_cancel()-> this method allows to run the code after the delay time
    window_tab.after_cancel(timer)
    canvas.itemconfig(timer_text, text="00:00")
    timer_label.config(text="Timer")
    # after the reset button is clicked and after that clicked start button it should go to the work session (rep1)
    global reps
    reps = 0


# creating the reset button
reset_button = Button(text="Reset", font=("Courier", 10, "bold"), highlightthickness=0, bg="light pink",
                      activebackground="light pink", command=reset_timer)
reset_button.grid(column=2, row=2)


# ----------STOP MECHANISM-----------#
def stop_timer():
    window_tab.after_cancel(timer)
    global reps
    reps = 0


# creating stop button
stop_button = Button(text="Stop", font=("Courier", 10, "bold"), highlightthickness=0, bg="light yellow",
                     activebackground="light yellow",command=stop_timer)
stop_button.grid(column=1, row=3)


# ------ TIMER COUNT DOWN MECHANISM----------------#
def count_down(count):
    # print(count)
    # introducing a method to start the countdown after a delay time 1000 = 1secs
    # to avoid timer going beyond 0 and negative values. adding a if statement
    # converting the seconds into mins: seconds
    count_min = math.floor(count / 60)
    count_sec = count % 60
    # to show this "5: '00' adding a if statemnet to solve that
    if count_sec < 10:
        count_sec = f"0{count_sec}"
    canvas.itemconfig(timer_text, text=f"{count_min}:{count_sec}")
    if count >= 0:
        global timer
        # this after method should show in the timer text into the canvas image text
        timer = window_tab.after(1000, count_down, count - 1)
        # the timer should start only when the start button is clicked
        # after the work session the timer should go to the break sessions
    else:
        start_timer()


window_tab.mainloop()
